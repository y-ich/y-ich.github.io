#ifndef __VIDEO_UTIL_YUV_H__
#define __VIDEO_UTIL_YUV_H__

int YUV4222YUV420P(int x_dim, int y_dim, void *yuv422, 
	void *y_out, void *u_out, void *v_out, int flip);

#endif /* __VIDEO_UTIL_YUV_H__ */
